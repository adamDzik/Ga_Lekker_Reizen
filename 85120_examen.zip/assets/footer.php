<section class="mt-auto">
    <!-- Footer -->
    <footer class="bg-secondary text-white text-center ">
        <!-- Grid container -->
        <div class="container p-4">
            <!--Grid row-->
            <div class="row">
                <!--Grid column-->
                <div class="col-lg-6 col-md-12 mb-4 mb-md-0 mt-5">
                    <h5 class="text-uppercase">Contact Gegevens</h5>

                    <p>Address: Heer Bokelweg 255, 3032 AD Rotterdam</p>
                    <p>Telefoon: 088 200 1500</p>
                    <p>Address: Heer Bokelweg 255, 3032 AD Rotterdam</p>
                    <p>Address: Heer Bokelweg 255, 3032 AD Rotterdam</p>
                </div>
                <!--Grid column-->

                <!--Grid column-->
                <div class="col-lg-6 col-md-6 mb-4 mb-md-0">
                    <h5 class="text-uppercase">Openingstijden</h5>

                    <ul class="list-unstyled mb-0">
                        <li>
                            <p>Maandag: 8:15 - 18:00</p>
                        </li>
                        <li>
                            <p>Dinsdag: 8:15 - 18:00</p>
                        </li>
                        <li>
                            <p>Woensdag: 8:15 - 18:00</p>
                        </li>
                        <li>
                            <p>Donderdag: 8:15 - 18:00</p>
                        </li>
                        <li>
                            <p>vrijdag: 8:15 - 18:00</p>
                        </li>
                        <li>
                            <p>Zaterdag: Gesloten</p>
                        </li>
                        <li>
                            <p>Zondag: Gesloten</p>
                        </li>
                    </ul>
                </div>
                <!--Grid column-->

            </div>
            <!--Grid row -->
        </div>
        <!-- Grid container -->

        <!-- Copyright -->
        <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
            © 2022 Copyright:
            <a class="text-white" href="/index.php">GaLekkerReizen.nl</a>
        </div>
        <!-- Copyright -->
    </footer>
    <!-- Footer -->
</section>
