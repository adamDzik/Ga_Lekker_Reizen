<?php
session_start();
// Check of je ingelogd bent, zo niet stuur naar de index.
if(isset($_SESSION['Docent_ID']) || !empty($_SESSION['Docent_ID'])) {
    if ($_SESSION['Docent_ID']) {

    } else{
        header("location: ../../index.php");
    }
}
// Check of je ingelogd bent, zo niet stuur naar de index.
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    // Als je niet ingelogd bent, laat login knop zien
    header("location: ../../index.php");
} else{

}

//Check of je als student in bent gelogd zo ja, dan stuur naar de index
if(isset($_SESSION['Student_ID']) || !empty($_SESSION['Student_ID'])) {
    if ($_SESSION['Student_ID']) {
        header("location: ../../index.php");
    }
}

// Controleer het bestaan van de id-parameter voordat deze verder word verwerkt.
if (isset($_GET["Reis_ID"]) && !empty(trim($_GET["Reis_ID"]))){
    // Voeg config bestand toe
    include "../../config/config.php";

    // Bereid een select statement.
    $sql = "SELECT * FROM Reis WHERE Reis_ID = :Reis_ID";

    if ($stmt = $pdo->prepare($sql)){
        // Bind variabelen aan de prepared statement als parameters
        $stmt->bindParam(":Reis_ID", $param_User_ID);

        // Zet parameters.
        $param_User_ID = trim($_GET["Reis_ID"]);

        // Poging om de prepared statement uit te voeren.
        if ($stmt->execute()){
            if ($stmt->rowCount() == 1){
                // Haal de resultaatrij op als een associatieve array.
                // Sinds de result set een rij bevat, hoeft er geen while loop gebruikt te worden.
                $rij = $stmt->fetch(PDO::FETCH_ASSOC);

                // Haal individuele veldwaarden op
                $Titel = $rij["Titel"];
                $Bestemming = $rij["Bestemming"];
                $Omschrijving = $rij["Omschrijving"];
                $Begindatum = $rij["Begindatum"];
                $Einddatum = $rij["Einddatum"];
                $Einddatum = $rij["Aantal_Plekken"];
            } else{
                // URL bevat geen geldige ID-parameter. Doorverwijzen naar error pagina.
                header("location: error_page.php");
                exit();
            }
        } else{
            echo "Oops! Er is iets fout gegaan. Probeer het later opnieuw.";
        }
    }

    // Sluit de statement.
    unset($stmt);

    // Sluit de connectie.
    unset($pdo);
} else{
    // URL bevat geen id-parameter. Doorverwijzen naar foutpagina.
    header("location: ../error_page.php");
    exit();
}
?>

<!-- Html Code -->
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Toon Gebruikers</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/stylesheet.css">
</head>
<body>
<div class="wrapper forms">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h1 class="mt-5">Reis Gegevens</h1>
                <form>
                    <div class="form-group">
                        <label>Titel</label>
                        <p><input disabled type="text" value="<?php echo $rij["Titel"]; ?>"></p>
                    </div>
                    <div class="form-group">
                        <label>Bestemming</label>
                        <p><input disabled type="text" value="<?php echo $rij["Bestemming"]; ?>"></p>
                    </div>
                    <div class="form-group">
                        <label>Omschrijving</label>
                        <p><textarea disabled><?php echo $rij["Omschrijving"]; ?></textarea></p>
                    </div>
                    <div class="form-group">
                        <label>Begindatum</label>
                        <p><input disabled type="date" value="<?php echo $rij["Begindatum"]; ?>"></p>
                    </div>
                    <div class="form-group">
                        <label>Einddatum</label>
                        <p><input disabled type="date" value="<?php echo $rij["Einddatum"]; ?>"></p>
                    </div>
                    <div class="form-group">
                        <label>Aantal plekken</label>
                        <p><input disabled type="number" value="<?php echo $rij["Aantal_Plekken"]; ?>"></p>
                    </div>
                </form>
                <p><a href="reis.php" class="btn btn-primary">Terug</a></p>
            </div>
        </div>
    </div>
</div>
</body>
</html>