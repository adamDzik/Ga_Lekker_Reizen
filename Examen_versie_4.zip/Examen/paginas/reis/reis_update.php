<?php
// Voeg update.php bestand toe.
include "../../php/verwerk/reis_update_verwerk.php";

//Check of je als student in bent gelogd zo ja, dan stuur naar de index
if(isset($_SESSION['Student_ID']) || !empty($_SESSION['Student_ID'])) {
    if ($_SESSION['Student_ID']) {
        header("location: ../../index.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Reis</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/stylesheet.css">
</head>
<body>
<div class="wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mt-5">Update Reis</h2>
                <form action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                    <div class="form-group">
                        <div class="form-group">
                            <div class="form-group">
                                <label>Titel</label>
                                <input type="text" name="Titel" class="form-control <?php echo (!empty($Titel_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Titel; ?>" >
                                <span class="invalid-feedback"><?php echo $Titel_err;?></span>
                            </div>
                            <div class="form-group">
                                <label>Bestemming</label>
                                <input type="text" name="Bestemming" class="form-control <?php echo (!empty($Bestemming_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Bestemming; ?>">
                                <span class="invalid-feedback"><?php echo $Bestemming_err;?></span>
                            </div>

                            <label>Address</label>
                            <textarea name="Omschrijving" class="form-control <?php echo (!empty($Omschrijving_err)) ? 'is-invalid' : ''; ?>"><?php echo $Omschrijving; ?></textarea>
                            <span class="invalid-feedback"><?php echo $Omschrijving_err;?></span>
                        </div>
                        <label>Name</label>
                        <input type="date" name="Begindatum" class="form-control <?php echo (!empty($Begindatum_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Begindatum; ?>">
                        <span class="invalid-feedback"><?php echo $Begindatum_err;?></span>
                    </div>
                    <div class="form-group">
                        <label>Salary</label>
                        <input type="date" name="Einddatum" class="form-control <?php echo (!empty($Einddatum_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Einddatum; ?>">
                        <span class="invalid-feedback"><?php echo $Einddatum_err;?></span>
                    </div>
                    <div class="form-group">
                        <label>Aantal plekken</label>
                        <input type="number" name="Aantal_Plekken" class="form-control <?php echo (!empty($Aantal_Plekken_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $Aantal_Plekken; ?>" >
                        <span class="invalid-feedback"><?php echo $Aantal_Plekken_err;?></span>
                    </div>
                    <input type="hidden" name="Reis_ID" value="<?php echo $Reis_ID; ?>"/>
                    <input type="submit" class="btn btn-primary" value="Submit">
                    <a href="reis.php" class="btn btn-secondary ml-2">Terug</a>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
