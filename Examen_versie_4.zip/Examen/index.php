<?php

// Voeg de navbar.php
include "assets/navbar.php";
?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Index</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- initialiseer tooltips -->
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>
</head>
<body class="d-flex flex-column min-vh-100">
<!-- Carousel met foto's -->
<div id="carouselExampleIndicators" class="carousel slide mt-4 pl-3 pr-3" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" style=" width:100%; height: 700px !important;">
        <div class="carousel-item active">
            <img class="d-block w-100" src="assets/img/walibi.jpeg" alt="First slide">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100 h-100" src="assets/img/efteling.jpeg" alt="Second slide">
        </div>
        <div class="carousel-item">
            <img class="d-block w-100 h-100" src="assets/img/camping.jpeg" alt="Third slide">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- divider -->
<div class="border-top ml-4 mr-4 mt-5"></div>

<!-- over ons -->
<div class="row mt-5">
<div class="col-md-8 offset-md-2 text-center">
    <p>Hoi! Wij zijn Ga Lekker Reizen!</p>
    <p>Ga je met ons lekker mee op ries? Top!</p>
    <p>Schrij jezelf dan zo snel mogelijk in om met ons meet te kunnen naar leuke avonturen!</p>
</div>
</div>

<div class="border-top ml-4 mr-4 mt-5"></div>
<div class="row mt-5">
    <div class="col-md-8 offset-md-2 mb-5 text-center">
        <?php
        // Initialize the session
        session_start();

        if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {

        } else{

            echo "<a href='paginas/reis_inschrijf/reis_inschrijf.php' style='font-size: 20px;' class='font-weight-bold btn btn-outline-success my-2 my-sm-0 pt-3 pl-4 pb-3 pr-4'>Schrijf in!</a>";

        }
        ?>
    </div>
</div>



    <?php
    // Voeg de footer.php
    include "assets/footer.php";
    ?>
</body>
</html>