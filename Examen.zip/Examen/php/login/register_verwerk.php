<?php
// Voeg config bestand toe
include "../config/config.php";

// Definieer variabelen en initialiseer met lege waarden
$studentnummer = $naam = $achternaam = $email = $wachtwoord = $confirm_wachtwoord = "";
$studentnummer_err = $naam_err = $achternaam_err = $email_err = $wachtwoord_err = $confirm_wachtwoord_err = "";

// Formuliergegevens verwerken wanneer formulier wordt ingediend
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Valideer Studentnummer
    if(empty(trim($_POST["studentnummer"]))){
        $studentnummer_err = "Voer een studentnummer in.";
    } else{
        $studentnummer = trim($_POST["studentnummer"]);
    }

    // Valideer Naam
    if(empty(trim($_POST["naam"]))){
        $naam_err = "Voer je voornaam.";
    } else{
        $naam = trim($_POST["naam"]);
    }

    // Valideer Achternaam
    if(empty(trim($_POST["achternaam"]))){
        $achternaam_err = "Voer je achternaam in.";
    } else {
        $achternaam = trim($_POST["achternaam"]);
    }

    // Valideer Email
    if(empty(trim($_POST["email"]))){
        $email_err = "Voer een email in.";
    } else{

        // Bereid een select statement voor
        $sql = "SELECT student_id FROM student WHERE email = :email";

        if($stmt = $pdo->prepare($sql)){
            // Bind variabelen aan de prepared statement als parameters
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);

            // Stel parameters in
            $param_email = trim($_POST["email"]);

            // Poging om de prepared statement uit te voeren
            if($stmt->execute()){
                if($stmt->rowCount() == 1){
                    $email_err = "Dit emailadres in al in gebruik.";
                } else{
                    $email = trim($_POST["email"]);
                }
            } else{
                echo "Oeps! Er is iets fout gegaan. Probeer het later opnieuw.";
            }

            // Sluit de statement
            unset($stmt);
        }
    }

    // Valideer wachtwoord
    if(empty(trim($_POST["wachtwoord"]))){
        $wachtwoord_err = "Voer een wachtwoord in.";
    } elseif(strlen(trim($_POST["wachtwoord"])) < 6){
        $wachtwoord_err = "Wachtwoord moet minimaal 6 tekens bevatten.";
    } else{
        $wachtwoord = trim($_POST["wachtwoord"]);
    }

    // Valideer wachtwoord bevestig
    if(empty(trim($_POST["confirm_wachtwoord"]))){
        $confirm_wachtwoord_err = "Bevestig je wachtwoord.";
    } else{
        $confirm_wachtwoord = trim($_POST["confirm_wachtwoord"]);
        if(empty($wachtwoord_err) && ($wachtwoord != $confirm_wachtwoord)){
            $confirm_wachtwoord_err = "Wachtwoord komt niet overeen.";
        }
    }

    // Controleer invoerfouten voordat u deze in de database invoegt
    if(empty($studentnummer_err) && empty($naam_err) && empty($achternaam_err) && empty($email_err) && empty($wachtwoord_err) && empty($confirm_wachtwoord_err)){

        // Bereid een insert statement voor
        $sql = "INSERT INTO student (studentnummer, naam, achternaam, email, wachtwoord) VALUES (:studentnummer, :naam, :achternaam, :email, :wachtwoord)";

        if($stmt = $pdo->prepare($sql)){
            // Bind variabelen aan de prepared statement als parameters
            $stmt->bindParam("studentnummer", $param_studentnummer, PDO::PARAM_STR);
            $stmt->bindParam("naam", $param_naam, PDO::PARAM_STR);
            $stmt->bindParam("achternaam", $param_achternaam, PDO::PARAM_STR);
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);
            $stmt->bindParam(":wachtwoord", $param_wachtwoord, PDO::PARAM_STR);

            // Stel parameters in

            $param_email = $email;
            $param_studentnummer = $studentnummer;
            $param_naam = $naam;
            $param_achternaam = $achternaam;
            $param_wachtwoord = password_hash($wachtwoord, PASSWORD_DEFAULT); // Creates a password hash

            // Poging om de prepared statement uit te voeren
            if($stmt->execute()){
                // Verstuur naar de login pagina
                header("location: login.php");
            } else{
                echo "Oeps! Er is iets fout gegaan. Probeer het later opnieuw.";
            }

            // Sliuit de statement
            unset($stmt);
        }
    }

    // Sluit de connectie
    unset($pdo);
}
?>
