<?php
// Initialize the session
session_start();




// wachtwoord moet 255 lengte hebben in de database plus bug fixen




// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: ../index.php");
    exit;
}

// Include config file
require_once "../config/config.php";

// Define variables and initialize with empty values
$email = $wachtwoord = "";
$email_err = $wachtwoord_err = $login_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Check if username is empty
    if(empty(trim($_POST["email"]))){
        $email_err = "Please enter username.";
    } else{
        $email = trim($_POST["email"]);
    }

    // Check if password is empty
    if(empty(trim($_POST["wachtwoord"]))){
        $wachtwoord_err = "Please enter your password.";
    } else{
        $wachtwoord = trim($_POST["wachtwoord"]);
    }

    // Validate credentials
    if(empty($email_err) && empty($wachtwoord_err)){
        // Prepare a select statement
        $sql = "SELECT * FROM student WHERE email = :email";

        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":email", $param_email, PDO::PARAM_STR);

            // Set parameters
            $param_email = trim($_POST["email"]);

            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Check if username exists, if yes then verify password
                if($stmt->rowCount() == 1){
                    if($row = $stmt->fetch()){
                        $student_id = $row["student_id"];
                        $email = $row["email"];
                        $hashed_wachtwoord = $row["wachtwoord"];
                        if(password_verify($wachtwoord, $hashed_wachtwoord)){
                            // Password is correct, so start a new session
                            session_start();

                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["student_id"] = $student_id;
                            $_SESSION["email"] = $email;

                            // Redirect user to welcome page
                            header("location: ../index.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }

    // Close connection
    unset($pdo);
}
?>