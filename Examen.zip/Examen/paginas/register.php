<?php
// Voeg config register_verwerk toe
include "../php/login/register_verwerk.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/stylesheet.css">
</head>
<body>
<div class="wrapper">
    <h2>Registreer</h2>
    <p>Maak een account aan.</p>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group">
            <label>Studentnummer</label>
            <input type="number" name="studentnummer" class="form-control <?php echo (!empty($studentnummer_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $studentnummer; ?>">
            <span class="invalid-feedback"><?php echo $studentnummer_err; ?></span>
        </div>
        <div class="form-group">
            <label>voornaam</label>
            <input type="text" name="naam" class="form-control <?php echo (!empty($naam_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $naam; ?>">
            <span class="invalid-feedback"><?php echo $naam_err; ?></span>
        </div>
        <div class="form-group">
            <label>Achternaam</label>
            <input type="text" name="achternaam" class="form-control <?php echo (!empty($achternaam_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $achternaam; ?>">
            <span class="invalid-feedback"><?php echo $achternaam_err; ?></span>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="Email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
            <span class="invalid-feedback"><?php echo $email_err; ?></span>
        </div>
        <div class="form-group">
            <label>Wachtwoord</label>
            <input type="password" name="wachtwoord" class="form-control <?php echo (!empty($wachtwoord_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $wachtwoord_err; ?>">
            <span class="invalid-feedback"><?php echo $wachtwoord_err; ?></span>
        </div>
        <div class="form-group">
            <label>Bevestig Wachtwoord</label>
            <input type="password" name="confirm_wachtwoord" class="form-control <?php echo (!empty($confirm_wachtwoord_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_wachtwoord; ?>">
            <span class="invalid-feedback"><?php echo $confirm_wachtwoord_err; ?></span>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Submit">
            <input type="reset" class="btn btn-secondary ml-2" value="Reset">
        </div>
        <p>Already have an account? <a href="login.php">Login here</a>.</p>
    </form>
</div>
</body>
</html>