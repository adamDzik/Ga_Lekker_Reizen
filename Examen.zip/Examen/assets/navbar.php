<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<nav class="navbar navbar-light bg-light justify-content-between">
    <a class="navbar-brand">Ga Lekker Reizen</a>
    <form class="form-inline">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">LOGIN</button>
    </form>
</nav>